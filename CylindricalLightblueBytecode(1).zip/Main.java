import java.io.File;
import java.util.Scanner;

class Main {
  public static String[] variables = new String[6];
  public static String[] function = new String[0];
  public static void main(String[] args) {
    File input = new File(args[0]);
    if(input.isDirectory()){
      for(int i = 0; i < input.listFiles().length; i++){
                readToArray(input.listFiles()[i]);
      }
    } else {
      readToArray(input);
    }

  }

  public static void readToArray(File target){
    try {
      Scanner scan = new Scanner(target);
      int lines = 1;
      int flines = 1;
      while (scan.hasNextLine()) {
        String line = scan.nextLine();
        if(lines <= 3){
          String[] splitLine = line.split(" ", 2);
          for(int i = 0; i < splitLine.length; i++){
            variables[i] = splitLine[i];
            System.out.println(variables[i]);
          }
          lines++;
        }
      scan.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}